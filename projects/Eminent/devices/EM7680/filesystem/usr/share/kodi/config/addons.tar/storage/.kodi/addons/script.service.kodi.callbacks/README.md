script.service.kodi.callbacks
=======================
Props to pilluli for initial idea

This is an all new version using a Publisher-Subscriber model.

For usage details, please see the wiki: http://kodi.wiki/view/Add-on:Kodi_Callbacks

Please report problems on the kodi forum at: http://forum.kodi.tv/showthread.php?tid=256170
