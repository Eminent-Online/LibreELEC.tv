#!/usr/bin/env sh
echo $1 $2